package always.goodapps.adoptme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
